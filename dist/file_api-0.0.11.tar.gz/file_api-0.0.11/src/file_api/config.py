class Config:
    BASE_PATH: str = "/home/rrr/Documents/test_dir"
